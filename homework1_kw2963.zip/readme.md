# Homework1
Kuan-Hsuan Wu, kw2963

## frontend URL
http://homework1-frontend.s3-website-us-east-1.amazonaws.com/

## Yelp Scrips
I use YelpDataCollector.py as my Yelp scraper script, and I run it in lambda

## file names
### 1) Frontend code (all files)
cloud-hw1-starter  
### 2) All Lambda Functions
LF0.py, LF1.py, LF2.py, YelpDataCollector.py  
### 3) YAML file generated through API Gateway
AI Customer Service API-test-stage-swagger.yaml  
### 4) readme file
readme.md  
### 5) Yelp scraper script
YelpDataCollector.py

## References
1. AWS Official Tutorial
2. TA's Code
3. Some stack overflow answers